#import <Cordova/CDV.h>
@interface Whatsapp:CDVPlugin

- (void)send:(CDVInvokedUrlCommand*)command;

@end
